<ul role="navigation" class="pagination">
    <li class="page-item disabled">
        <a href="#" rel="prev" class="page-link">‹</a>
    </li>
    <li aria-current="page" class="page-item disabled">
        <span class="page-link">1</span>
    </li>
    <li aria-disabled="true" aria-label="Next »" class="page-item disabled">
        <span aria-hidden="true" class="page-link">›</span>
    </li>
</ul>